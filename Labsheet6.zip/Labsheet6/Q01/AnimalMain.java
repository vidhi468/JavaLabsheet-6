// Lab Sheet 6 - Q1: Method Overriding (Animal -> Cat)

class Animal {
    void makeSound() {
        System.out.println("The animal makes a sound.");
    }
}

class Cat extends Animal {
    // Method overriding: same name and signature as the parent method,
    // but the child gives its own body (here the cat "barks", as the question asks)
    @Override
    void makeSound() {
        System.out.println("The cat barks: Woof! Woof!");
    }
}

public class AnimalMain {
    public static void main(String[] args) {
        Animal animal = new Animal();
        Animal cat = new Cat(); // parent reference, child object -> the overridden method runs
        animal.makeSound();
        cat.makeSound();
    }
}
