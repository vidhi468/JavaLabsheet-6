// Lab Sheet 6 - Q2: Method Overriding (Vehicle -> Car)

class Vehicle {
    void drive() {
        System.out.println("The vehicle is being driven.");
    }
}

class Car extends Vehicle {
    @Override // tells the compiler we are overriding the parent's drive()
    void drive() {
        System.out.println("Repairing a car");
    }
}

public class VehicleMain {
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();
        Vehicle car = new Car(); // runtime polymorphism
        vehicle.drive();
        car.drive();
    }
}
