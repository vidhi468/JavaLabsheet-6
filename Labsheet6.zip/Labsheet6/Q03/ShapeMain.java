// Lab Sheet 6 - Q3: Method Overriding (Shape -> Rectangle)

class Shape {
    // Default version: a general shape has no specific formula
    double getArea() {
        return 0;
    }
}

class Rectangle extends Shape {
    private double length;
    private double width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    // Overrides getArea() with the rectangle formula
    @Override
    double getArea() {
        return length * width;
    }
}

public class ShapeMain {
    public static void main(String[] args) {
        Shape shape = new Shape();
        Shape rectangle = new Rectangle(8, 5);
        System.out.println("Area of generic shape : " + shape.getArea());
        System.out.println("Area of rectangle     : " + rectangle.getArea());
    }
}
