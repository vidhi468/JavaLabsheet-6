// Lab Sheet 6 - Q4: Employee -> HRManager (override work(), add addEmployee())

class Employee {
    protected String name;
    protected double salary;

    Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    void work() {
        System.out.println(name + " is doing general office work.");
    }

    double getSalary() {
        return salary;
    }
}

class HRManager extends Employee {
    private Employee[] team = new Employee[5]; // employees added by the HR manager
    private int count = 0;

    HRManager(String name, double salary) {
        super(name, salary);
    }

    // Overridden method
    @Override
    void work() {
        System.out.println(name + " (HR Manager) is recruiting and managing employees.");
    }

    // New method that exists only in the child class
    void addEmployee(Employee employee) {
        if (count < team.length) {
            team[count++] = employee;
            System.out.println(employee.name + " added by " + name + ". Total employees: " + count);
        } else {
            System.out.println("Team is full. Cannot add " + employee.name);
        }
    }
}

public class EmployeeMain {
    public static void main(String[] args) {
        Employee emp = new Employee("Rahul", 30000);
        HRManager hr = new HRManager("Meera", 60000);

        emp.work();
        System.out.println("Salary: Rs. " + emp.getSalary());
        hr.work();
        System.out.println("Salary: Rs. " + hr.getSalary());
        hr.addEmployee(emp);
        hr.addEmployee(new Employee("Sonal", 32000));
    }
}
