// Lab Sheet 6 - Q5: BankAccount -> SavingsAccount (override withdraw())

class BankAccount {
    protected double balance;

    BankAccount(double balance) {
        this.balance = balance;
    }

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited Rs. " + amount + " | Balance: Rs. " + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn Rs. " + amount + " | Balance: Rs. " + balance);
        } else {
            System.out.println("Withdrawal failed: insufficient balance or invalid amount.");
        }
    }
}

class SavingsAccount extends BankAccount {
    private static final double MIN_BALANCE = 100; // balance must not fall below this

    SavingsAccount(double balance) {
        super(balance);
    }

    // Overridden: blocks a withdrawal that would leave less than Rs. 100
    @Override
    void withdraw(double amount) {
        if (amount > 0 && (balance - amount) >= MIN_BALANCE) {
            balance -= amount;
            System.out.println("Withdrawn Rs. " + amount + " | Balance: Rs. " + balance);
        } else {
            System.out.println("Withdrawal of Rs. " + amount + " denied: balance cannot fall below Rs. "
                    + MIN_BALANCE);
        }
    }
}

public class BankAccountMain {
    public static void main(String[] args) {
        System.out.println("--- Normal Account ---");
        BankAccount normal = new BankAccount(1000);
        normal.deposit(500);
        normal.withdraw(1450); // allowed in a normal account

        System.out.println("\n--- Savings Account ---");
        BankAccount savings = new SavingsAccount(1000);
        savings.deposit(500);
        savings.withdraw(1450); // denied: would leave Rs. 50
        savings.withdraw(1000); // allowed: leaves Rs. 500
    }
}
