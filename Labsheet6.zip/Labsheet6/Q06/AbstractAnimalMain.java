// Lab Sheet 6 - Q6: Abstract class Animal with abstract method sound()

// Abstract class: cannot be instantiated; may contain abstract methods
abstract class Animal {
    // Abstract method: no body, every child class MUST implement it
    abstract void sound();
}

class Lion extends Animal {
    @Override
    void sound() {
        System.out.println("Lion roars: Roarrr!");
    }
}

class Tiger extends Animal {
    @Override
    void sound() {
        System.out.println("Tiger growls: Grrrr!");
    }
}

public class AbstractAnimalMain {
    public static void main(String[] args) {
        // new Animal();  // not allowed: Animal is abstract
        Animal[] animals = new Animal[2];
        animals[0] = new Lion();
        animals[1] = new Tiger();
        for (int i = 0; i < animals.length; i++) {
            animals[i].sound();
        }
    }
}
