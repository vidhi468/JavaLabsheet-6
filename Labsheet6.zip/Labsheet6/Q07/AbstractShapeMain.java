// Lab Sheet 6 - Q7: Abstract class Shape (Circle and Triangle)

abstract class Shape {
    abstract double calculateArea();
    abstract double calculatePerimeter();
}

class Circle extends Shape {
    private double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double calculateArea() {
        return Math.PI * radius * radius;
    }

    @Override
    double calculatePerimeter() {
        return 2 * Math.PI * radius; // circumference
    }
}

class Triangle extends Shape {
    private double a, b, c; // three sides

    Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    double calculateArea() {
        double s = (a + b + c) / 2; // Heron's formula
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }

    @Override
    double calculatePerimeter() {
        return a + b + c;
    }
}

public class AbstractShapeMain {
    public static void main(String[] args) {
        Shape circle = new Circle(7);
        Shape triangle = new Triangle(3, 4, 5);

        System.out.println("Circle    -> Area: " + circle.calculateArea()
                + " | Perimeter: " + circle.calculatePerimeter());
        System.out.println("Triangle  -> Area: " + triangle.calculateArea()
                + " | Perimeter: " + triangle.calculatePerimeter());
    }
}
