// Lab Sheet 6 - Q8: Abstract class BankAccount (SavingsAccount and CurrentAccount)

abstract class BankAccount {
    protected String accountNo;
    protected double balance;

    BankAccount(String accountNo, double balance) {
        this.accountNo = accountNo;
        this.balance = balance;
    }

    abstract void deposit(double amount);
    abstract void withdraw(double amount);

    // Normal (concrete) method shared by all child classes
    void displayBalance() {
        System.out.println("Account " + accountNo + " balance: Rs. " + balance);
    }
}

class SavingsAccount extends BankAccount {
    private static final double MIN_BALANCE = 500;

    SavingsAccount(String accountNo, double balance) {
        super(accountNo, balance);
    }

    @Override
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Savings: deposited Rs. " + amount);
        } else {
            System.out.println("Savings: invalid deposit amount.");
        }
    }

    // Savings account must keep a minimum balance
    @Override
    void withdraw(double amount) {
        if (amount > 0 && (balance - amount) >= MIN_BALANCE) {
            balance -= amount;
            System.out.println("Savings: withdrawn Rs. " + amount);
        } else {
            System.out.println("Savings: withdrawal of Rs. " + amount + " denied (minimum balance Rs. "
                    + MIN_BALANCE + ").");
        }
    }
}

class CurrentAccount extends BankAccount {
    private static final double OVERDRAFT_LIMIT = 5000;

    CurrentAccount(String accountNo, double balance) {
        super(accountNo, balance);
    }

    @Override
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Current: deposited Rs. " + amount);
        } else {
            System.out.println("Current: invalid deposit amount.");
        }
    }

    // Current account allows the balance to go negative up to the overdraft limit
    @Override
    void withdraw(double amount) {
        if (amount > 0 && (balance - amount) >= -OVERDRAFT_LIMIT) {
            balance -= amount;
            System.out.println("Current: withdrawn Rs. " + amount);
        } else {
            System.out.println("Current: withdrawal of Rs. " + amount + " denied (overdraft limit Rs. "
                    + OVERDRAFT_LIMIT + ").");
        }
    }
}

public class AbstractBankAccountMain {
    public static void main(String[] args) {
        BankAccount savings = new SavingsAccount("SA1001", 2000);
        BankAccount current = new CurrentAccount("CA2001", 1000);

        savings.deposit(1000);
        savings.withdraw(2800); // denied: would leave Rs. 200
        savings.withdraw(2000); // allowed
        savings.displayBalance();

        System.out.println();
        current.deposit(500);
        current.withdraw(4000); // allowed through overdraft
        current.withdraw(3000); // denied: beyond overdraft limit
        current.displayBalance();
    }
}
