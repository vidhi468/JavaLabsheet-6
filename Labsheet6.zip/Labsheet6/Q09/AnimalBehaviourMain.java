// Lab Sheet 6 - Q9: Abstract class Animal with eat() and sleep()

abstract class Animal {
    protected String name;

    Animal(String name) {
        this.name = name;
    }

    abstract void eat();
    abstract void sleep();
}

class Lion extends Animal {
    Lion(String name) { super(name); }

    @Override
    void eat() { System.out.println(name + " (Lion) hunts and eats meat."); }

    @Override
    void sleep() { System.out.println(name + " (Lion) sleeps up to 20 hours a day."); }
}

class Tiger extends Animal {
    Tiger(String name) { super(name); }

    @Override
    void eat() { System.out.println(name + " (Tiger) eats meat after hunting alone."); }

    @Override
    void sleep() { System.out.println(name + " (Tiger) sleeps in a shady spot during the day."); }
}

class Deer extends Animal {
    Deer(String name) { super(name); }

    @Override
    void eat() { System.out.println(name + " (Deer) grazes on grass and leaves."); }

    @Override
    void sleep() { System.out.println(name + " (Deer) takes short naps and stays alert."); }
}

public class AnimalBehaviourMain {
    public static void main(String[] args) {
        Animal[] animals = { new Lion("Simba"), new Tiger("Sherkhan"), new Deer("Bambi") };
        for (int i = 0; i < animals.length; i++) {
            animals[i].eat();
            animals[i].sleep();
            System.out.println();
        }
    }
}
