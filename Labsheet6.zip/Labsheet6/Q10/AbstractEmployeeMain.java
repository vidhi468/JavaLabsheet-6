// Lab Sheet 6 - Q10: Abstract class Employee (Manager and Programmer)

abstract class Employee {
    protected String name;
    protected int id;
    protected double basicSalary;

    Employee(String name, int id, double basicSalary) {
        this.name = name;
        this.id = id;
        this.basicSalary = basicSalary;
    }

    abstract double calculateSalary();
    abstract void displayInfo();
}

class Manager extends Employee {
    private double allowance;
    private double bonus;

    Manager(String name, int id, double basicSalary, double allowance, double bonus) {
        super(name, id, basicSalary);
        this.allowance = allowance;
        this.bonus = bonus;
    }

    // Manager salary = basic + allowance + bonus
    @Override
    double calculateSalary() {
        return basicSalary + allowance + bonus;
    }

    @Override
    void displayInfo() {
        System.out.println("Role   : Manager");
        System.out.println("ID     : " + id);
        System.out.println("Name   : " + name);
        System.out.println("Salary : Rs. " + calculateSalary());
    }
}

class Programmer extends Employee {
    private int overtimeHours;
    private double overtimeRate;

    Programmer(String name, int id, double basicSalary, int overtimeHours, double overtimeRate) {
        super(name, id, basicSalary);
        this.overtimeHours = overtimeHours;
        this.overtimeRate = overtimeRate;
    }

    // Programmer salary = basic + overtime pay
    @Override
    double calculateSalary() {
        return basicSalary + (overtimeHours * overtimeRate);
    }

    @Override
    void displayInfo() {
        System.out.println("Role   : Programmer");
        System.out.println("ID     : " + id);
        System.out.println("Name   : " + name);
        System.out.println("Overtime hours : " + overtimeHours);
        System.out.println("Salary : Rs. " + calculateSalary());
    }
}

public class AbstractEmployeeMain {
    public static void main(String[] args) {
        Employee[] employees = new Employee[2];
        employees[0] = new Manager("Anita Verma", 501, 60000, 15000, 10000);
        employees[1] = new Programmer("Karan Singh", 502, 45000, 12, 500);

        for (int i = 0; i < employees.length; i++) {
            employees[i].displayInfo();
            System.out.println("-----------------------------");
        }
    }
}
