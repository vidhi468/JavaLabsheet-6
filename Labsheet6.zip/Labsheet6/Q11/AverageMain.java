// Lab Sheet 6 - Q11: Average of ten numbers and count of numbers above the average
import java.util.Scanner;

class NumberStats {
    private double[] numbers;

    // 'this' separates the instance variable from the constructor parameter
    NumberStats(int size) {
        this.numbers = new double[size];
    }

    void readNumbers(Scanner sc) {
        System.out.println("Enter " + this.numbers.length + " numbers:");
        for (int i = 0; i < this.numbers.length; i++) {
            this.numbers[i] = sc.nextDouble();
        }
    }

    double calculateAverage() {
        double sum = 0;
        for (int i = 0; i < this.numbers.length; i++) {
            sum += this.numbers[i];
        }
        return sum / this.numbers.length;
    }

    int countAboveAverage() {
        double average = this.calculateAverage(); // 'this' also calls another method of the same object
        int count = 0;
        for (int i = 0; i < this.numbers.length; i++) {
            if (this.numbers[i] > average) {
                count++;
            }
        }
        return count;
    }

    void displayResult() {
        System.out.println("Average of the numbers : " + this.calculateAverage());
        System.out.println("Numbers above average  : " + this.countAboveAverage());
    }
}

public class AverageMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NumberStats stats = new NumberStats(10);
        stats.readNumbers(sc);
        stats.displayResult();
        sc.close();
    }
}
